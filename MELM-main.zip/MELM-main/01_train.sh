#!/bin/bash

python trainer.py \
 --file_dir './data/' \
 --ckpt_dir './ckpt/ckpt.pt'

